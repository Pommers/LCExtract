from unittest import TestCase
from

class TestDataClass(TestCase):
    def test_get_data(self):
        self.fail()
