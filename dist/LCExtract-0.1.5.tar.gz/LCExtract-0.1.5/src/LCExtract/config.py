"""
module
------
config.py

summary
-------
Configuration and global data for package
"""

# Global variables
filterSelection = ''
defaultFileName = 'data/test_new.csv'
